package com.cg.pizzaorder.ui;

import java.util.Date;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {

	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		IPizzaOrderService iPizzaOrderSevice=new PizzaOrderService();
		String pizzaType = null,mobile,address,customerName;
		int number=0;
		while (!(number==3)) {
			System.out.println("1.enter Details\n2.get order details\n3.exit");
			System.out.println("enter number:");
			number=input.nextInt();
			try {
				switch (number) {
				case 1:
					System.out.println("enter the name of the customer:");
					customerName = input.next();
					System.out.println("enter customer address");
					address = input.next();
					System.out.println("enter customer phone number");
					mobile = input.next();
					System.out.println("enter type of pizza topping preffered");
					pizzaType = input.next();
					Date date=new Date();
					int orderId = iPizzaOrderSevice.placeOrder(new Customer(customerName, address, mobile),
							new PizzaOrder(pizzaType));
					System.out.println("Pizza Order successfully placed with Order id: "+orderId+" at time: "+date);
					break;
				case 2:
					System.out.println("enter order id:");
					System.out.println(iPizzaOrderSevice.getOrderDetails(input.nextInt()));
					break;
				default:
					break;
				}
			} catch (PizzaException e) {
				e.printStackTrace();
			} 
		}
	}

}

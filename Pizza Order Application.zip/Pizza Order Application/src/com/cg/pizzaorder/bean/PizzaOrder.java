package com.cg.pizzaorder.bean;

public class PizzaOrder {
	private int orderId;
	private int customerId;
	private double totalPrice;
	private String pizzaType;
	public PizzaOrder() {}
	public PizzaOrder(int orderId, int customerId, String pizzaType) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.pizzaType = pizzaType;
	}

	public PizzaOrder(String pizzaType) {
		super();
		this.pizzaType = pizzaType;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getPizzaType() {
		return pizzaType;
	}
	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}
	@Override
	public String toString() {
		return "PizzaOrder [orderId=" + orderId + ", customerId=" + customerId + ", totalPrice=" + totalPrice
				+ ", pizzaType=" + pizzaType +  "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PizzaOrder other = (PizzaOrder) obj;
		if (customerId != other.customerId)
			return false;
		if (orderId != other.orderId)
			return false;
		if (pizzaType == null) {
			if (other.pizzaType != null)
				return false;
		} else if (!pizzaType.equals(other.pizzaType))
			return false;
		if (Double.doubleToLongBits(totalPrice) != Double.doubleToLongBits(other.totalPrice))
			return false;
		return true;
	}


	

}
